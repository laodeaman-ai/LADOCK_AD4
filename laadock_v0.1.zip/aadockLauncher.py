import os, sys, shutil, glob, requests, gzip, subprocess
from Bio.PDB import PDBParser
from Bio.PDB.PDBIO import PDBIO
import dill

# Membaca variabel-variabel dari config.txt
with open('vsconfig.txt') as f:
    for line in f:
        if line.startswith('#'):
            continue
        if line.startswith(' '):
            continue
        key, value = line.strip().split(' = ')
        exec(key + ' = ' + value)

# Menyimpan variabel-variabel menggunakan dill
with open('aadockvs/config.pkl', 'wb') as f:
    dill.dump({
        'vr': vr,
        'vl': vl,
        'vs': vs,
        'utility': utility,
        'autodock4_path': autodock4_path,
        'autodock_gpu_path': autodock_gpu_path,
        'autodock_vina_path': autodock_vina_path,
        'adt': adt,
        'pdblink': pdblink,
        'pdb_file': pdb_file,
        'pdbself': pdbself,
        'rec_db': rec_db,
        'liglink': liglink,
        'lig_file': lig_file,
        'ligself': ligself,
        'lig_db': lig_db,
        'npts': npts,
        'spacing': spacing,
        'ga_num_evals': ga_num_evals,
        'ga_run': ga_run,
        'ga_pop_size': ga_pop_size,
        'exhaustiveness' : exhaustiveness,
        'extparameter': extparameter,
        'nsr': nsr,
        'job_name': job_name,
        'job_dir': job_dir
    }, f)
    
from aadockvs.aadockvs import AADockVS
aadock = AADockVS()
aadock.Main()