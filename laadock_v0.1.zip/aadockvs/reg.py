import gspread
from oauth2client.service_account import ServiceAccountCredentials
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import random
import string

# konfigurasi Google Sheets API
scope = ['https://spreadsheets.google.com/feeds',
         'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('aadockvs/aadock.json', scope)
client = gspread.authorize(creds)
sheet = client.open_by_key("14u2jtukx5td1KYJIVvVI-xODU7g5zbwjnytWTNOhhfg").sheet1
nama = ""

def send_activation_code (email, activation_code):
    # konfigurasi email pengirim
    sender_email = 'laodeaman.ai@gmail.com'
    sender_password = 'fqgsgppgfodpyjvh'
    sender_name = 'La Ode Aman'
    
    # konfigurasi email penerima
    receiver_email = email
    receiver_name = nama
    
    # membuat email
    msg = MIMEMultipart()
    msg['From'] = f'{sender_name} <{sender_email}>'
    msg['To'] = f'{receiver_name} <{receiver_email}>'
    msg['Subject'] = 'Aktivasi Aplikasi AADock'
    
    # isi email
    body = f'Halo {receiver_name},\n\nTerima kasih telah melakukan registrasi pada aplikasi AADock. Berikut adalah kode aktivasi Anda:\n\n{activation_code}\n\nSalam,\n{sender_name}'
    msg.attach(MIMEText(body, 'plain'))
    
    # mengirim email
    with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
        smtp.ehlo()
        smtp.starttls()
        smtp.ehlo()
        smtp.login(sender_email, sender_password)
        smtp.sendmail(sender_email, receiver_email, msg.as_string())

def generate_activation_code():
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(12))

# fungsi untuk melakukan registrasi
def register():
    # input data dari user
    nama = input("Name : ")
    email = input("A valid email address : ")
    afiliasi = input("Affiliation : ")
    kota = input("City : ")
    negara = input("Country : ")
    
    # generate kode aktivasi
    activation_code = generate_activation_code()
    
    # simpan data user dan kode aktivasi pada database Google Sheets
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    sheet.append_row([nama, email, afiliasi, kota, negara, activation_code, current_time, "1"])
    
    # kirim email ke user dengan kode aktivasi
    send_activation_code(email, activation_code)   
    print("Registrasi berhasil. Silakan cek email Anda untuk mendapatkan kode aktivasi.")

# fungsi untuk melakukan validasi kode aktivasi
import datetime
import pandas as pd

def validate_activation_code():
    # input kode aktivasi dari user
    activation_code = input("Masukkan kode aktivasi: ")
    
    # validasi kode aktivasi pada database Google Sheets
    data = sheet.get_all_values()
    df = pd.DataFrame(data[1:], columns=data[0])  
    col_index = 5  # indeks kolom dimulai dari 0
    if activation_code in df.iloc[:, col_index].values:
        print("Kode aktivasi valid. Selamat menggunakan AADock!") 
        row_index = (df.iloc[:, col_index] == activation_code).idxmax() + 2
        
        # merekam waktu penggunaan terakhir
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sheet.update_cell(row_index, 9, current_time)
        
        # update frekuensi penggunaan
        old_freq = int(sheet.cell(row_index, 8).value)
        new_freq = old_freq + 1
        sheet.update_cell(row_index, 8, new_freq)         
        return True
        
    else:
        print("Kode aktivasi tidak valid. Silakan coba lagi.")
        return False

        