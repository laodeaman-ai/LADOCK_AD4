import os
import sys
import shutil
import glob
import requests
import gzip
import subprocess
from aadockvs.function import autogrid
from aadockvs.function import prepare_gpf
from aadockvs.function import prepare_dpf
from aadockvs.function import autodock4
from aadockvs.function import autodock_gpu
from aadockvs.function import calculate_center_and_axes
from aadockvs.function import extract_vina_energy
from aadockvs.function import write_lowest_energy_ligand
from aadockvs.function import move_best_poses
from aadockvs.function import move_dlg_files
from aadockvs.function import summarize_results
from aadockvs.function import autodock_vina
from aadockvs.function import process_VinaResult
import pandas as pd

def validation(output, dlgs_are_here, best_poses_are_here, adt, npts, spacing, extparameter, ga_num_evals, ga_pop_size, ga_run, utility, autodock, exhaustiveness, cpu_num):
  
  for pdbs in os.listdir(output):
    print("\t"+pdbs)
    pdbs_path=os.path.join(output,pdbs)
    lig_ref_path=os.path.join(pdbs_path,pdbs+"_lig.pdb")
    os.chdir(pdbs_path)
    os.mkdir(dlgs_are_here)
    os.mkdir(best_poses_are_here)
    dlg_path=os.path.join(pdbs_path,dlgs_are_here)
    best_poses_path=os.path.join(pdbs_path,best_poses_are_here)
    prepare_gpf(adt, pdbs+"_lig.pdbqt", pdbs+".pdbqt", npts, spacing, extparameter)
    autogrid(pdbs+".gpf", pdbs+".glg")
    
    if utility == "AutoDock4":      
      prepare_dpf(adt, pdbs+"_lig.pdbqt", pdbs+".pdbqt", ga_num_evals, ga_pop_size, ga_run, extparameter)
      autodock4(autodock, pdbs+"_lig"+"_"+pdbs+".dpf", pdbs+"_lig"+"_"+pdbs+".dlg")
      write_lowest_energy_ligand(adt,pdbs+"_lig"+"_"+pdbs+".dlg")
      summarize_results(adt,pdbs+".pdbqt",pdbs+"_lig"+"_"+pdbs+".csv")
      move_dlg_files(pdbs_path, dlg_path)
      move_best_poses(pdbs_path, best_poses_path)      
      csv1 = open(pdbs_path+"/"+pdbs+"_total.csv",'+a')
      csv2 = open(pdbs_path+"/"+"summary_of_results_1.0",'r')
      csv2cont = csv2.readlines()
      csv1.write(str(csv2cont[0].lstrip('#').replace("#",", ")))
      csv1=csv1.write(str(csv2cont[1])) 

    elif utility == "AutoDock-GPU":
      autodock_gpu(autodock, pdbs+".maps.fld", pdbs+"_lig.pdbqt", pdbs+"_lig.pdbqt", ga_run)
      write_lowest_energy_ligand(adt,pdbs+"_lig.dlg")
      summarize_results(adt,pdbs+".pdbqt",pdbs+"_lig"+"_"+pdbs+".csv")
      move_dlg_files(pdbs_path, dlg_path)
      move_best_poses(pdbs_path, best_poses_path)
      csv1 = open(pdbs_path+"/"+pdbs+"_total.csv",'+a')
      csv2 = open(pdbs_path+"/"+"summary_of_results_1.0",'r')
      csv2cont = csv2.readlines()
      csv1.write(str(csv2cont[0].lstrip('#').replace("#",", ")))
      csv1=csv1.write(str(csv2cont[1]))
      
    elif utility == "AutoDock-Vina":
      config = pdbs+"_config.txt"
      log = pdbs+"_log.txt"
      receptor = pdbs+".pdbqt"
      ligand_pdb = pdbs+"_lig.pdb"
      ligand_pdbqt = pdbs+"_lig.pdbqt"
      center_x, center_y, center_z, size_x, size_y, size_z = calculate_center_and_axes (ligand_pdb, npts)       
      with open(config, "w") as config:
        config.write("receptor = " + str(receptor) + "\n")
        config.write("ligand = " + str(ligand_pdbqt) + "\n\n")
        config.write("center_x = " + str(center_x) + "\n")
        config.write("center_y = " + str(center_y) + "\n")
        config.write("center_z = " + str(center_z) + "\n\n")
        config.write("size_x = " + str(size_x) + "\n")
        config.write("size_y = " + str(size_y) + "\n")
        config.write("size_z = " + str(size_z) + "\n\n")
        config.write("exhaustiveness = " + str(exhaustiveness) + "\n")      
      autodock_vina(autodock, config.name, cpu_num)
      process_VinaResult(adt, pdbs+"_lig_out.pdbqt", receptor)
      vina_result, inter, intra, unbound = extract_vina_energy (pdbs+"_lig_out_model1.pdbqt")
      
      csv_path = pdbs_path+"/"+pdbs+"_total.csv"
      df = pd.DataFrame(columns=['ligand_name', 'vina_result', 'inter', 'intra', 'unbound'])
      df.loc[0] = [pdbs+"_lig_out_model1.pdbqt", vina_result, inter, intra, unbound]
      df.to_csv(csv_path, index=False)
      
      shutil.move(pdbs + '_lig_out_model1.pdbqt', best_poses_path)
      shutil.move(pdbs + '_lig_out.pdbqt', dlg_path)
      files_to_delete = []      
      for i in range(2, 1000):
        files_to_delete.append(pdbs + "_lig_out_model" + str(i) + ".pdbqt")
      for file in files_to_delete:
        if os.path.exists(file):
          os.remove(file)