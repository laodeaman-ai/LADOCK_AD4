import os
import sys
import shutil
import glob
import requests
import gzip
import subprocess
from Bio.PDB import PDBParser
from Bio.PDB.PDBIO import PDBIO
from aadockvs.function import split_chains

def preparationLink (pdb_file, rec_db_tmp):
    rcsb=[line.strip() for line in open(pdb_file,'r')]
    rcsb.sort()
    print("Get PDB from RCSB webserver (" +((",").join(rcsb))+"):")
    for rec in rcsb:
      rec_url="http://files.rcsb.org/download/"+rec+".pdb"
      print("\t"+rec_url)
      response = requests.get(rec_url)
      open(rec_db_tmp+'/'+rec+".pdb", "wb").write(response.content)
      parser = PDBParser()
      structure = parser.get_structure(rec, rec_db_tmp + '/' + rec + ".pdb")
      split_chains(structure, rec_db_tmp)
      os.remove(rec_db_tmp + "/" + rec + ".pdb") 
      
def preparationSelf (rec_db, rec_db_tmp):
    print("Get PDB from local storage:")
    for file in os.listdir(rec_db):
      if file.endswith('.pdb'):
        pdb_id = os.path.splitext(file)[0][-4:]
        print("\t"+pdb_id.upper())
        parser = PDBParser()
        structure = parser.get_structure(pdb_id, os.path.join(rec_db, file))
        split_chains(structure, rec_db_tmp)

def SplittingRecLig (rec_db_tmp, output, rcptrchains, nuniqchains):
  print("Splitting PDB into receptor and ligand for:")
  for pdbs in os.listdir(rec_db_tmp):    
    pdbpath = os.path.join(rec_db_tmp, pdbs)
    pdb = os.path.splitext(pdbs)[0]    
    print("\t"+pdb)
    path = output+'/'+pdb     
    os.mkdir(path)
    with open(pdbpath) as lines, open (path+"/"+pdb+"_lig.pdb","w") as l, open(path+"/"+pdb+".pdb","w") as r:
      for line in lines:
        if any (rcptrchain in line for rcptrchain in rcptrchains):
          r.write(line)
        if not any (rcptrchain in line for rcptrchain in rcptrchains):
          if  not any (nuniqchain in line for nuniqchain in nuniqchains):
            l.write(line)