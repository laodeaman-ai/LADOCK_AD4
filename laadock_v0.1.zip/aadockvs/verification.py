import os
import sys
import shutil
import glob
import requests
import gzip
import subprocess
from aadockvs.function import prepare_ligand
from aadockvs.function import prepare_receptor

def verification(output, adt):  
  for pdbs in os.listdir(output):
    print("\t"+pdbs)
    pathpy=os.path.join(output,pdbs) 
    os.chdir(pathpy)
    prepare_ligand(adt, pdbs+"_lig.pdb")
  for pdbs in os.listdir(output):
    pathpy=os.path.join(output,pdbs)
    if not os.path.exists(os.path.join(pathpy,pdbs+"_lig.pdbqt")):
      shutil.rmtree(pathpy)       
  for pdbs in os.listdir(output):
    pathpy=os.path.join(output,pdbs) 
    os.chdir(pathpy)
    prepare_receptor(adt, pdbs+".pdb", pdbs+".pdbqt")  
  for pdbs in os.listdir(output):
    pathpy=os.path.join(output,pdbs)
    if not os.path.exists(os.path.join(pathpy,pdbs+".pdbqt")):
      shutil.rmtree(pathpy) 