import os
import sys
import shutil
import glob
import requests
import gzip
import subprocess
from Bio.PDB import PDBParser
from Bio.PDB.PDBIO import PDBIO
import dill
from aadockvs.preparation import preparationLink
from aadockvs.preparation import preparationSelf
from aadockvs.preparation import SplittingRecLig
from aadockvs.verification import verification
from aadockvs.validation import validation
from aadockvs.vsMain import VirtualScreeningLink, VirtualScreeningSelf
from aadockvs.function import autogrid
from aadockvs.function import prepare_gpf
from aadockvs.function import prepare_dpf
from aadockvs.function import autodock4
from aadockvs.function import autodock_gpu
from aadockvs.function import write_lowest_energy_ligand
from aadockvs.function import move_best_poses
from aadockvs.function import move_dlg_files
from aadockvs.function import summarize_results
from aadockvs.function import calculate_center_and_axes
from aadockvs.function import autodock_vina
from aadockvs.function import process_VinaResult
from aadockvs.function import extract_vina_energy
from aadockvs.reg import register
from aadockvs.reg import  validate_activation_code
import multiprocessing

# Memuat variabel-variabel dari file
with open('aadockvs/config.pkl', 'rb') as f:
  data = dill.load(f)
# Mengakses variabel-variabel
vr = data['vr']
vl = data['vl']
vs = data['vs']
utility = data['utility']
adt = data['adt']
autodock4_path = data['autodock4_path']
autodock_gpu_path = data['autodock_gpu_path']
autodock_vina_path = data['autodock_vina_path']
pdblink = data['pdblink']
pdb_file = data['pdb_file']
pdbself = data['pdbself']
rec_db = data['rec_db']
liglink = data['liglink']
lig_file = data['lig_file']
ligself = data['ligself']
lig_db = data['lig_db']
npts = data['npts']
spacing = data['spacing']
ga_num_evals = data['ga_num_evals']
ga_run = data['ga_run']
ga_pop_size = data['ga_pop_size']
exhaustiveness = data['exhaustiveness']
num_cpus = multiprocessing.cpu_count()
cpu_num = num_cpus - 1
extparameter = data['extparameter']
nsr = data['nsr']
job_name = data['job_name']
job_dir = data['job_dir']

if utility == "AutoDock4":
  autodock = autodock4_path
  if not os.path.exists(autodock):
    autodock = "autodock4"
  else:
    print("Providing the docking simulation software (AutoDock4, Autodock-GPU or AutoDock-Vina) on your system")
elif utility == "AutoDock-GPU":
    autodock = autodock_gpu_path
    if not os.path.exists(autodock):
      print("Providing the docking simulation software (AutoDock4, Autodock-GPU or AutoDock-Vina) on your system")  
elif utility == "AutoDock-Vina":
  autodock = autodock_vina_path
  if not os.path.exists(autodock):
    autodock = "vina"
  else:
    print("Providing the docking simulation software (AutoDock4, Autodock-GPU or AutoDock-Vina) on your system")
else:
  print("Providing the docking simulation software (AutoDock4, Autodock-GPU or AutoDock-Vina) on your system")

def nsrFunction(nsr):
    if isinstance(nsr, str):
        if nsr == "" or nsr.isspace():  # jika nsr kosong atau hanya berisi spasi
            nsr = []
    elif isinstance(nsr, list):
        if not nsr:  # jika nsr kosong
            nsr = []
    else:
        raise ValueError("nsr harus berupa string atau list")
    return nsr
nsr = nsrFunction(nsr)
dlgs_are_here = "dlgs_are_here"
best_poses_are_here = "best_poses_are_here"

#addional setting:
metals=["  F"," Mg"," MG","  P"," SA","  S"," Cl"," CL"," Ca"," CA"," Mn", " MN", " Fe", " FE", " Zn", " ZN", " Br", " BR", " I", " NA","  K", " CU", " Cu"]
chains=[" A", " B"," C"," D"," E"," F"," G"," H"," I"," J"," K"," L"," M"," N"," O"," P"," Q"," R"," S"," T"," U"," V", " W"," X"," Y"," Z"]
aacids=["ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE", "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL"]
nuniqs = ["HOH","SEP","PTR","EDO","SO4","CPQ","CAC","NAG","NDP","CIT","GOL","ACY","NO2","NAP","SCN","PCA","PO4"] + nsr
aacidchains = [x+y for x in aacids for y in chains]
nuniqchains = [x+y for x in nuniqs for y in chains]
metalchains = [x+y for x in metals for y in chains]
rcptrchains = aacidchains+metalchains

current_dir = "{}/{}".format(job_dir,job_name)
output = "{}/output".format(current_dir)
lig_db_tmp = "{}/lig_db_tmp".format(current_dir)
rec_db_tmp = "{}/rec_db_tmp".format(current_dir)
rcsb = ""
lig = ""

class AADockVS():
    def aadockMain(self):
        if os.path.exists(current_dir):
            shutil.rmtree(current_dir)
            os.mkdir(current_dir)
            os.mkdir(output)
            os.mkdir(rec_db_tmp)
            os.mkdir(lig_db_tmp)
        else:
            os.mkdir(current_dir)
            os.mkdir(output)
            os.mkdir(rec_db_tmp)
            os.mkdir(lig_db_tmp)
        os.chdir(current_dir)
        print ("Starting...")
        if liglink == True:
            preparationLink (pdb_file, rec_db_tmp)
        if ligself == True:
            preparationSelf (rec_db, rec_db_tmp)
        SplittingRecLig (rec_db_tmp, output, rcptrchains, nuniqchains)    
        if vr is True:
            print("PDB Verification")
            verification(output, adt)
        if vl is True:
            print("Docking Procedure Validation"+"("+utility+")")            
            validation(output, dlgs_are_here, best_poses_are_here, adt, npts, spacing, extparameter, ga_num_evals, ga_pop_size, ga_run, utility, autodock, exhaustiveness, cpu_num)
        if vs is True:
            print("Virtual Screening Process"+"("+utility+")")
            if liglink == True:
                VirtualScreeningLink (output, lig_file, dlgs_are_here, best_poses_are_here, adt, npts, spacing, extparameter, utility, autodock, ga_num_evals, ga_pop_size, ga_run, exhaustiveness, cpu_num)
            if ligself == True:
                VirtualScreeningSelf (output, lig_db, dlgs_are_here, best_poses_are_here, adt, npts, spacing, extparameter, utility, autodock, ga_num_evals, ga_pop_size, ga_run, exhaustiveness, cpu_num)

    def Main(self):
        # main program
        print("Selamat datang di AADock: Virtual Screening Tools!")
        opsi = input("Silakan pilih opsi: 1. Registrasi, 2. Masukkan kode aktivasi\n")
        if opsi == "1":
            register()
        elif opsi == "2":
            if validate_activation_code():
                self.aadockMain()
        else:
            print("Opsi tidak valid. Silakan coba lagi.")
