from re import VERBOSE
from Bio.PDB import PDBParser
from Bio.PDB.PDBIO import PDBIO
import os
import sys
import shutil
import glob
import requests
import gzip
import subprocess
import pandas as pd

def split_chains(structure, rec_db_tmp):
  pdb_chains = structure.get_chains()   
  for chain in pdb_chains:
    io = PDBIO()
    io.set_structure(chain)
    f = structure.get_id() + "_" + chain.get_id()
    io.save(os.path.join(rec_db_tmp, f + ".pdb"))

def prepare_ligand(adt, input_file):
  try:
    command = "python2.7 {}/prepare_ligand4.py -l {} -v".format(adt, input_file)
    subprocess.check_call(command, shell=True)
  except:
    return

def prepare_receptor(adt, input_file, output_file):
  try:
    command = "python2.7 {}/prepare_receptor4.py -r {} -o {} -v".format(adt, input_file, output_file)
    subprocess.check_call(command, shell=True)
  except:
    return

def prepare_gpf(adt, input_ligand, input_receptor, npts, spacing, extparameter):
    command = "python2.7 {}/prepare_gpf4.py -l {} -r {} -p npts={} -p spacing={} -p parameter_file={} -y".format(adt, input_ligand, input_receptor, npts, spacing, extparameter)
    subprocess.check_call(command, shell=True)

def prepare_gpf_vs(adt, input_ligand, input_receptor, npts, spacing, extparameter, gpf_ref):
    command = "python2.7 {}/prepare_gpf4.py -l {} -r {} -p npts={} -p spacing={} -p parameter_file={} -i {}".format(adt, input_ligand, input_receptor, npts, spacing, extparameter, gpf_ref)
    subprocess.check_call(command, shell=True)
    
def prepare_dpf(adt, input_ligand, input_receptor, ga_num_evals, ga_pop_size, ga_run, extparameter):
    command = "python2.7 {}/prepare_dpf42.py -l {} -r {} -p ga_num_evals={} -p ga_pop_size={} -p ga_run={} -p parameter_file={}".format(adt, input_ligand, input_receptor, ga_num_evals, ga_pop_size, ga_run, extparameter)
    subprocess.check_call(command, shell=True)

def prepare_dpf_vs(adt, input_ligand, input_receptor, ga_num_evals, ga_pop_size, ga_run, extparameter, dpf_ref):
    command = "python2.7 {}/prepare_dpf42.py -l {} -r {} -p ga_num_evals={} -p ga_pop_size={} -p ga_run={} -p parameter_file={} -i {}".format(adt, input_ligand, input_receptor, ga_num_evals, ga_pop_size, ga_run, extparameter, dpf_ref)
    subprocess.check_call(command, shell=True)

def obabel_split(f1filepath, f1dirpath, f1):
    f1dirpath_str = str(f1dirpath)
    f1_str = str(f1)
    command = "obabel {} -osdf -O {}/{}.sdf -m".format(f1filepath, f1dirpath_str, f1_str)
    subprocess.check_call(command, shell=True)

def convert_sdf_to_pdb(sdf, pdb):    
    command = "obabel {} -opdb -O {} -h".format(sdf, pdb)
    subprocess.check_call(command, shell=True)

def autogrid(gpf_file, glg_file):
    command = "autogrid4 -p {} -l {}".format(gpf_file, glg_file)
    subprocess.check_call(command, shell=True)

def autodock4(autodock, dpf_file, dlg_file):
    command = "{} -p {} -l {}".format(autodock, dpf_file, dlg_file)
    subprocess.check_call(command, shell=True)

def autodock_vina(autodock, config_file, cpu_num):
    command = "{} --config {} --cpu {}".format(autodock, config_file, cpu_num)
    subprocess.check_call(command, shell=True)

def autodock_gpu(autodock, ffield, lfile, xrayfile, ga_run):
    command = "{} --ffile {} --lfile {} --xraylfile {} --nrun {} --dlgoutput 1".format(autodock, ffield, lfile, xrayfile, ga_run)
    subprocess.check_call(command, shell=True)

def write_lowest_energy_ligand(adt,dlg_file):
    command = "python2.7 {}/write_lowest_energy_ligand.py -f {}".format(adt,dlg_file)
    subprocess.check_call(command, shell=True)

def summarize_results(adt,input_receptor_pdbqt,output_file):
    command = "python2.7 {}/summarize_results41.py -r {} -d ./ -e -u".format(adt,input_receptor_pdbqt,output_file)
    subprocess.check_call(command, shell=True)

def process_VinaResult(adt, file_log, input_receptor):
    command = "python2.7 {}/process_VinaResult.py -f {} -r {}".format(adt, file_log, input_receptor)
    subprocess.check_call(command, shell=True)

def verification():  
  for pdbs in os.listdir(output):
    print("\tPDB processing: "+pdbs)
    pathpy=os.path.join(output,pdbs) 
    os.chdir(pathpy)
    prepare_ligand(adt, pdbs+"_lig.pdb")
  for pdbs in os.listdir(output):
    pathpy=os.path.join(output,pdbs)
    if not os.path.exists(os.path.join(pathpy,pdbs+"_lig.pdbqt")):
      shutil.rmtree(pathpy) 
  for pdbs in os.listdir(output):
    pathpy=os.path.join(output,pdbs) 
    os.chdir(pathpy)
    prepare_receptor(adt, pdbs+".pdb", pdbs+".pdbqt")  
  for pdbs in os.listdir(output):
    pathpy=os.path.join(output,pdbs)
    if not os.path.exists(os.path.join(pathpy,pdbs+".pdbqt")):
      shutil.rmtree(pathpy)

dlgs_are_here="dlgs_are_here"
best_poses_are_here="best_poses_are_here"

def move_dlg_files(src_dir, target_dir):
    for dlg_file in os.listdir(src_dir):
        if dlg_file.endswith('.dlg'):
            src_file_path = os.path.join(src_dir, dlg_file)
            dst_file_path = os.path.join(target_dir, dlg_file)
            if os.path.isfile(dst_file_path):
                # Rename the file if it already exists in the target directory
                i = 1
                while os.path.isfile(dst_file_path):
                    base, ext = os.path.splitext(dlg_file)
                    new_filename = f"{base}({i}){ext}"
                    dst_file_path = os.path.join(target_dir, new_filename)
                    i += 1
            os.rename(src_file_path, dst_file_path)

def move_best_poses(src_dir, target_dir):
    for dlg_file in os.listdir(src_dir):
        if dlg_file.endswith('_BE.pdbqt'):
            src_file_path = os.path.join(src_dir, dlg_file)
            dst_file_path = os.path.join(target_dir, dlg_file)
            if os.path.isfile(dst_file_path):
                # Rename the file if it already exists in the target directory
                i = 1
                while os.path.isfile(dst_file_path):
                    base, ext = os.path.splitext(dlg_file)
                    new_filename = f"{base}({i}){ext}"
                    dst_file_path = os.path.join(target_dir, new_filename)
                    i += 1
            os.rename(src_file_path, dst_file_path)   

def calculate_center_and_axes(ligand_file, npts):
    with open(ligand_file, 'r') as file:
        lines = file.readlines()

    # Ambil posisi atom dari setiap baris pada file PDB
    x_coords = []
    y_coords = []
    z_coords = []
    for line in lines:
        if line.startswith('HETATM'):
            x_coords.append(float(line[31:38]))
            y_coords.append(float(line[39:46]))
            z_coords.append(float(line[47:54]))

    # Hitung koordinat pusat molekul
    center_x = (max(x_coords) + min(x_coords)) / 2
    center_y = (max(y_coords) + min(y_coords)) / 2
    center_z = (max(z_coords) + min(z_coords)) / 2
    
    # Hitung panjang sumbu x, y, dan z
    npts_list = npts.split(',')
    size_x = npts_list[0]
    size_y = npts_list[1]
    size_z = npts_list[2]
    
    return center_x, center_y, center_z, size_x, size_y, size_z

def extract_vina_energy(log_file):
    with open(log_file, 'r') as f:
        lines = f.readlines()

        vina_result = None
        inter = None
        intra = None
        unbound = None

        for line in lines:
            if line.startswith("REMARK VINA RESULT:"):
                vina_result = float(line.split()[3])

            elif line.startswith("REMARK INTER:"):
                inter = float(line.split()[2])

            elif line.startswith("REMARK INTRA:"):
                intra = float(line.split()[2])

            elif line.startswith("REMARK UNBOUND:"):
                unbound = float(line.split()[2])

        return vina_result, inter, intra, unbound