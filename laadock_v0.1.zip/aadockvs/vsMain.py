import os
import sys
import shutil
import glob
import requests
import gzip
import subprocess
from aadockvs.function import obabel_split
from aadockvs.function import autodock4
from aadockvs.function import autodock_gpu
from aadockvs.function import convert_sdf_to_pdb
from aadockvs.function import prepare_ligand
from aadockvs.function import prepare_dpf_vs
from aadockvs.function import prepare_gpf_vs
from aadockvs.function import autogrid
from aadockvs.function import write_lowest_energy_ligand
from aadockvs.function import move_best_poses
from aadockvs.function import move_dlg_files
from aadockvs.function import summarize_results
from aadockvs.function import calculate_center_and_axes
from aadockvs.function import autodock_vina
from aadockvs.function import process_VinaResult
from aadockvs.function import extract_vina_energy
import pandas as pd


def process_vs(recpath, f1, adt, pdbs, npts, spacing, extparameter, utility, autodock, ga_num_evals, ga_pop_size, ga_run, dlg_path, best_poses_path, exhaustiveness, cpu_num):
    # membuat nama file dengan ekstensi .sdf
    f1filepath = recpath + "/" + f1 + ".sdf"
    # split sdf dengan obabel
    obabel_split(f1filepath, recpath, f1)
    # menghapus file dengan ekstensi .sdf
    os.remove(f1filepath)
    # untuk setiap file dengan ekstensi .sdf di dalam folder, lakukan:
    for sdf in os.listdir(recpath):
        if sdf.endswith('.sdf'):
            # membuka file .sdf dan membaca baris pertama
            f1 = open((recpath + "/" + sdf), 'r')
            f2 = f1.readline().split("\n")[0]            
            # mengubah nama file .sdf sesuai dengan baris pertama
            old_sdf = os.path.join(recpath, sdf)
            new_sdf = os.path.join(recpath, f2 + '.sdf') 
            new_pdb = os.path.join(recpath, f2 + '.pdb')            
            shutil.copyfile(old_sdf, new_sdf)
            # mengonversi file .sdf menjadi .pdb
            if os.path.exists(new_sdf):
                convert_sdf_to_pdb(new_sdf, new_pdb)
            else:
                convert_sdf_to_pdb(old_sdf, new_pdb)
            os.remove(old_sdf)
            os.chdir(recpath)            
            # mempersiapkan file ligand untuk docking
            prepare_ligand(adt, f2 + ".pdb")
            # mempersiapkan file .gpf untuk virtual screening
            prepare_gpf_vs(adt, f2 + ".pdbqt", pdbs + ".pdbqt", npts, spacing, extparameter, pdbs + ".gpf")
            # membuat file grid .glg
            autogrid(pdbs + ".gpf", pdbs + ".glg")
            
            if utility == "AutoDock4":
                # mempersiapkan file .dpf untuk docking
                prepare_dpf_vs(adt, f2 + ".pdbqt", pdbs + ".pdbqt", ga_num_evals, ga_pop_size, ga_run, extparameter, pdbs + "_lig" + "_" + pdbs +  ".dpf")                
                # melakukan docking dengan Autodock4
                autodock4(autodock, f2 + "_" + pdbs + ".dpf", f2 + "_" + pdbs + ".dlg")
                # menulis hasil docking dengan energi terendah ke file .pdbqt                
                write_lowest_energy_ligand(adt, f2 + "_" + pdbs + ".dlg")
                # menampilkan ringkasan hasil docking
                summarize_results(adt, pdbs + ".pdbqt", f2 + ".csv")
                # memindahkan file .dlg ke folder hasil
                recpath=str(recpath)
                dlg_path=str(dlg_path)                
                move_dlg_files(recpath, dlg_path)
                # memindahkan file pose dengan energi terbaik ke folder hasil
                recpath=str(recpath)
                best_poses_path=str(best_poses_path)  
                move_best_poses(recpath, best_poses_path)
                # menambahkan hasil ringkasan ke file csv total
                pdbs=str(pdbs) 
                recpath=str(recpath) 
                csv1 = open(recpath + "/" + pdbs + "_total.csv", '+a')
                csv2 = open(recpath + "/" + "summary_of_results_1.0", 'r')
                csv2cont = csv2.readlines()
                csv1 = csv1.write(str(csv2cont[1]))
                # menghapus temporary files () 
                os.remove(f2+'.pdb')
                os.remove(f2+'.sdf')
                os.remove(f2+'.pdbqt')
                os.remove(f2 + "_" + pdbs + ".dpf")

            if utility == "AutoDock-GPU":
                autodock_gpu(autodock, pdbs+".maps.fld", f2+".pdbqt", f2+".pdbqt", ga_run)                                
                write_lowest_energy_ligand(adt, f2 + ".dlg")
                summarize_results(adt, pdbs + ".pdbqt", f2 + ".csv")
                recpath=str(recpath)
                dlg_path=str(dlg_path)                
                move_dlg_files(recpath, dlg_path)
                # memindahkan file pose dengan energi terbaik ke folder hasil
                recpath=str(recpath)
                best_poses_path=str(best_poses_path)  
                move_best_poses(recpath, best_poses_path)
                # menambahkan hasil ringkasan ke file csv total
                csv1 = open(recpath + "/" + pdbs + "_total.csv", '+a')
                csv2 = open(recpath + "/" + "summary_of_results_1.0", 'r')
                csv2cont = csv2.readlines()
                csv1 = csv1.write(str(csv2cont[1]))
                # menghapus temporary files () 
                os.remove(f2+'.pdb')
                os.remove(f2+'.sdf')
                os.remove(f2+'.pdbqt')
                os.remove(f2+'.xml')
                
            elif utility == "AutoDock-Vina":
                config = pdbs + "_config.txt"
                log = pdbs + "_log.txt"
                receptor = pdbs +  ".pdbqt"
                ligand_pdb = f2 + ".pdb"
                native_pdb = pdbs + "_lig.pdb"
                ligand_pdbqt = f2 + ".pdbqt"
                center_x, center_y, center_z, size_x, size_y, size_z = calculate_center_and_axes (native_pdb, npts)       
                with open(config, "w") as config:
                  config.write("receptor = " + str(receptor) + "\n")
                  config.write("ligand = " + str(ligand_pdbqt) + "\n\n")
                  config.write("center_x = " + str(center_x) + "\n")
                  config.write("center_y = " + str(center_y) + "\n")
                  config.write("center_z = " + str(center_z) + "\n\n")
                  config.write("size_x = " + str(size_x) + "\n")
                  config.write("size_y = " + str(size_y) + "\n")
                  config.write("size_z = " + str(size_z) + "\n\n")
                  config.write("exhaustiveness = " + str(exhaustiveness) + "\n")      
                autodock_vina(autodock, config.name, cpu_num)
                process_VinaResult(adt, f2 + "_out.pdbqt", receptor)
                vina_result, inter, intra, unbound = extract_vina_energy (f2 + "_out_model1.pdbqt")
                csv_path = recpath + "/" + pdbs + "_total.csv"
                df = pd.read_csv(csv_path)
                new_row = {'ligand_name': f2 + "_out_model1.pdbqt", 'vina_result': vina_result, 'inter': inter, 'intra': intra, 'unbound': unbound}
                df = df.append(new_row, ignore_index=True)
                df.to_csv(csv_path, mode='w', index=False)
                shutil.move(f2 + "_out_model1.pdbqt", best_poses_path)
                shutil.move(f2 + "_out.pdbqt", dlg_path)
                files_to_delete = []
                for i in range(2, 1000):
                    files_to_delete.append(f2 + "_out_model" + str(i) + ".pdbqt")
                for file in files_to_delete:
                  if os.path.exists(file):
                    os.remove(file)
                    
def VirtualScreeningSelf (output, lig_db, dlgs_are_here, best_poses_are_here, adt, npts, spacing, extparameter, utility, autodock, ga_num_evals, ga_pop_size, ga_run, exhaustiveness, cpu_num):
  for pdbs in os.listdir(output):
    print("\t"+pdbs)
    recpath=os.path.join(output, pdbs)
    dlg_path=os.path.join(recpath,dlgs_are_here)
    best_poses_path=os.path.join(recpath,best_poses_are_here)    
    for filegzpath in glob.glob(os.path.join(lig_db, "*.sdf.gz")):
        print("\t\tGet ligand database from "+filegzpath)       
        f1= 'sdf_tmp'        
        with gzip.open(os.path.join(filegzpath), 'rb') as f_in:
          with open(recpath+'/'+f1+'.sdf','wb') as f_out:
            shutil.copyfileobj(f_in, f_out)
        process_vs(recpath, f1, adt, pdbs, npts, spacing, extparameter, utility, autodock, ga_num_evals, ga_pop_size, ga_run, dlg_path, best_poses_path, exhaustiveness, cpu_num)
        
def VirtualScreeningLink (output, lig_file, dlgs_are_here, best_poses_are_here, adt, npts, spacing, extparameter, utility, autodock, ga_num_evals, ga_pop_size, ga_run, exhaustiveness, cpu_num):
  for pdbs in os.listdir(output):
    print("\t"+pdbs)
    recpath=os.path.join(output, pdbs)
    dlg_path=os.path.join(recpath,dlgs_are_here)
    best_poses_path=os.path.join(recpath,best_poses_are_here)    
    lig=[line.strip() for line in open(lig_file,'r')]
    for lig_url in lig:
        print("\t\tGet ligand database from "+lig_url)
        filegz=lig_url.split("/")[-1]
        f1= 'tmp_sdf'
        try:
          response = requests.get(lig_url)
          open(recpath+'/'+filegz, 'wb').write(response.content) 
        except:
          return
        filegzpath=os.path.join(recpath,filegz)
        with gzip.open(str(filegzpath), 'rb') as f_in:
          with open(recpath+'/'+f1+'.sdf','wb') as f_out:
            shutil.copyfileobj(f_in, f_out) 
        os.remove(filegzpath)
        process_vs(recpath, f1, adt, pdbs, npts, spacing, extparameter, utility, autodock, ga_num_evals, ga_pop_size, ga_run, dlg_path, best_poses_path, exhaustiveness, cpu_num)